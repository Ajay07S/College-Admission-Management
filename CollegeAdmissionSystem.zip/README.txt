
College Admission Management System - User Guide

Steps to Use:

1. Import the schema.sql into your MySQL server to create tables.
2. Insert initial course data using sample_data.sql.
3. Compile and run the Java program using your IDE or command line.
4. Use options to:
   - Register a new student.
   - Run the admin panel to process applications based on merit and cut-offs.
   - Export the approved admissions list as a CSV file.

Dependencies:
- MySQL Server
- Java SDK
- Apache Commons CSV Library

DB Configuration:
- URL: jdbc:mysql://localhost:3306/admission_db
- User: root
- Password: password
