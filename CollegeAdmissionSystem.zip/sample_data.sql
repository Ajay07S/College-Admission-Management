
INSERT INTO Courses(course_name, cutoff_score, seats_available) VALUES 
('Computer Science', 85, 3),
('Electronics', 80, 2),
('Mechanical', 75, 2);
