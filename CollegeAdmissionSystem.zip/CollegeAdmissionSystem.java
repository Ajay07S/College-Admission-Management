
import java.sql.*;
import java.util.*;
import java.io.FileWriter;
import org.apache.commons.csv.*;

public class CollegeAdmissionSystem {
    static final String DB_URL = "jdbc:mysql://localhost:3306/admission_db";
    static final String USER = "root";
    static final String PASS = "password";

    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) throws Exception {
        while (true) {
            System.out.println("\n1.Register Student\n2.Admin Panel\n3.Generate Admission List\n4.Exit");
            int ch = sc.nextInt();
            switch (ch) {
                case 1: registerStudent(); break;
                case 2: adminPanel(); break;
                case 3: generateCSV(); break;
                case 4: System.exit(0);
                default: System.out.println("Invalid");
            }
        }
    }

    static void registerStudent() {
        try (Connection con = DriverManager.getConnection(DB_URL, USER, PASS)) {
            System.out.println("Enter Name: ");
            String name = sc.next();
            System.out.println("Enter Email: ");
            String email = sc.next();
            System.out.println("Enter Score: ");
            float score = sc.nextFloat();
            System.out.println("Preferred Course: ");
            String course = sc.next();

            String sql = "INSERT INTO Students(name, email, score, course_pref) VALUES(?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setFloat(3, score);
            ps.setString(4, course);
            ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();
            int studentId = 0;
            if (rs.next()) studentId = rs.getInt(1);

            PreparedStatement ps2 = con.prepareStatement("SELECT course_id FROM Courses WHERE course_name=?");
            ps2.setString(1, course);
            ResultSet crs = ps2.executeQuery();
            int courseId = -1;
            if (crs.next()) courseId = crs.getInt("course_id");

            if (courseId != -1) {
                String appSql = "INSERT INTO Applications(student_id, course_id, status) VALUES(?, ?, 'Pending')";
                PreparedStatement aps = con.prepareStatement(appSql);
                aps.setInt(1, studentId);
                aps.setInt(2, courseId);
                aps.executeUpdate();
                System.out.println("Application Submitted.");
            } else {
                System.out.println("Course not found!");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    static void adminPanel() {
        try (Connection con = DriverManager.getConnection(DB_URL, USER, PASS)) {
            Statement stmt = con.createStatement();
            String sql = "SELECT a.app_id, s.name, s.score, c.course_name, c.cutoff_score, c.seats_available FROM Applications a JOIN Students s ON a.student_id=s.student_id JOIN Courses c ON a.course_id=c.course_id WHERE a.status='Pending'";
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                int appId = rs.getInt("app_id");
                String name = rs.getString("name");
                float score = rs.getFloat("score");
                String course = rs.getString("course_name");
                float cutoff = rs.getFloat("cutoff_score");
                int seats = rs.getInt("seats_available");

                System.out.printf("AppID: %d | %s | Score: %.2f | Course: %s | Cut-off: %.2f | Seats: %d\n",
                        appId, name, score, course, cutoff, seats);

                if (score >= cutoff && seats > 0) {
                    System.out.println("=> Approved");
                    PreparedStatement up1 = con.prepareStatement("UPDATE Applications SET status='Approved' WHERE app_id=?");
                    up1.setInt(1, appId);
                    up1.executeUpdate();

                    PreparedStatement up2 = con.prepareStatement("UPDATE Courses SET seats_available=seats_available-1 WHERE course_name=?");
                    up2.setString(1, course);
                    up2.executeUpdate();
                } else {
                    System.out.println("=> Rejected");
                    PreparedStatement up = con.prepareStatement("UPDATE Applications SET status='Rejected' WHERE app_id=?");
                    up.setInt(1, appId);
                    up.executeUpdate();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    static void generateCSV() {
        try (Connection con = DriverManager.getConnection(DB_URL, USER, PASS)) {
            Statement stmt = con.createStatement();
            String sql = "SELECT s.name, s.email, s.score, c.course_name FROM Applications a JOIN Students s ON a.student_id=s.student_id JOIN Courses c ON a.course_id=c.course_id WHERE a.status='Approved'";
            ResultSet rs = stmt.executeQuery(sql);

            FileWriter out = new FileWriter("admission_list.csv");
            CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT.withHeader("Name", "Email", "Score", "Course"));
            while (rs.next()) {
                printer.printRecord(rs.getString("name"), rs.getString("email"), rs.getFloat("score"), rs.getString("course_name"));
            }
            printer.flush();
            printer.close();
            System.out.println("CSV file generated: admission_list.csv");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
